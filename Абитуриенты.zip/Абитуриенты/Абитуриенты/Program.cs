using System;
using System.Windows.Forms;
using Абитуриенты.Auth;
using Абитуриенты.Data;

namespace Абитуриенты
{
    internal static class Program
    {
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            AppDomain.CurrentDomain.SetData("DataDirectory", Application.StartupPath);
            var dbPath = System.IO.Path.Combine(Application.StartupPath, "Абитуриенты.accdb");
            if (!System.IO.File.Exists(dbPath))
            {
                MessageBox.Show(
                    "Файл базы данных не найден:\n" + dbPath + "\n\nПоложите 'Абитуриенты.accdb' рядом с .exe (bin\\Debug).",
                    "Access база данных",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
                return;
            }

            var connectionString = DataStore.ResolveConnectionString(
                Properties.Settings.Default.АбитуриентыConnectionString);
            var store = new DataStore(connectionString);
            var ds = store.Load();

            using (var auth = new AuthorizationForm(store, ds))
            {
                if (auth.ShowDialog() != DialogResult.OK || auth.Session == null)
                    return;

                if (auth.Session.IsAdmin)
                    Application.Run(new AdminForm(store, ds, auth.Session));
                else if (auth.Session.IsUser)
                    Application.Run(new UserForm(store, ds, auth.Session));
                else
                    MessageBox.Show("Не удалось определить роль.", "Вход", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
    }
}
