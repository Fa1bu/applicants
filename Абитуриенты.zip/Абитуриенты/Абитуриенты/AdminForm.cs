using System;
using System.Collections.Generic;
using System.Drawing;
using System.Data;
using System.Windows.Forms;
using Абитуриенты.Auth;
using Абитуриенты.Data;
using Абитуриенты.Infrastructure;

namespace Абитуриенты
{
    public partial class AdminForm : Form
    {
        private readonly DataStore _store;
        private readonly АбитуриентыDataSet _ds;
        private readonly UserSession _session;

        public AdminForm(DataStore store, АбитуриентыDataSet ds, UserSession session)
        {
            _store = store ?? throw new ArgumentNullException(nameof(store));
            _ds = ds ?? throw new ArgumentNullException(nameof(ds));
            _session = session ?? throw new ArgumentNullException(nameof(session));

            InitializeComponent();
            AppTheme.Apply(this);
            BrandHeader.Apply(lblInstitution, lblContacts);
            HideTabHeaders(tabAdminInner);
            BuildTopNavigationButtons();

            lblUser.Text = $"Администратор: {_session.Login}   ({UserRoleParser.ToDisplayName(_session.RoleKind)})";
            if (cmbNewRole.Items.Count > 0)
                cmbNewRole.SelectedIndex = 1;
            tabAdminInner.SelectedTab = tabApplicants;
            BindAdmin();
            FormClosing += AdminForm_FormClosing;
        }

        private void AdminForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (e.Cancel)
                return;

            DataGridViewBindingFlush.FlushDataGridViews(this);
            if (!_ds.HasChanges())
                return;

            var answer = MessageBox.Show(
                "Есть несохранённые изменения. Сохранить перед выходом?",
                "Сохранение",
                MessageBoxButtons.YesNoCancel,
                MessageBoxIcon.Question);

            if (answer == DialogResult.Cancel)
            {
                e.Cancel = true;
                return;
            }

            if (answer != DialogResult.Yes)
                return;

            try
            {
                Validate();
                DataGridViewBindingFlush.FlushDataGridViews(this);
                _store.Save(_ds);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Не удалось сохранить: " + ex.Message, "Сохранение", MessageBoxButtons.OK, MessageBoxIcon.Error);
                e.Cancel = true;
            }
        }

        private static void HideTabHeaders(TabControl tabControl)
        {
            tabControl.Appearance = TabAppearance.FlatButtons;
            tabControl.ItemSize = new Size(0, 1);
            tabControl.SizeMode = TabSizeMode.Fixed;
        }

        private void BuildTopNavigationButtons()
        {
            var nav = TopBarLayout.Configure(panelTop, lblUser, btnDeleteSelected, btnSaveAll, btnExitApp);

            nav.Controls.Add(CreateNavButton("Абитуриенты", tabApplicants));
            nav.Controls.Add(CreateNavButton("Студенты", tabStudents));
            nav.Controls.Add(CreateNavButton("Специальности", tabSpecialitiesAdmin));
            nav.Controls.Add(CreateNavButton("Заявления", tabApplications));
            nav.Controls.Add(CreateNavButton("Список поступивших", tabAdmitted, 190));
            nav.Controls.Add(CreateNavButton("Пользователи", tabUsers));
        }

        private Button CreateNavButton(string text, TabPage target, int width = 138)
        {
            var btn = new Button
            {
                Text = text,
                Width = width,
                Height = 32,
                Margin = new Padding(4, 0, 4, 0)
            };

            btn.Click += (s, e) =>
            {
                tabAdminInner.SelectedTab = target;
                if (target == tabAdmitted)
                    RefreshAdmittedList();
            };
            return btn;
        }

        private void RefreshAdmittedList()
        {
            try
            {
                _store.LoadAdmittedList(_ds);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Не удалось обновить список поступивших: " + ex.Message, "Список поступивших", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void BindAdmin()
        {
            gridApplicants.DataSource = _ds.Абитуриенты;
            gridStudents.DataSource = _ds.Студенты;
            gridSpecialitiesAdmin.DataSource = _ds.Специальность;
            gridApplications.DataSource = _ds.Подача_заявлений;
            gridAdmitted.DataSource = _ds.Список_поступивших;
            gridUsers.DataSource = _ds.Регистрация;

            foreach (var g in new[] { gridApplicants, gridStudents, gridSpecialitiesAdmin, gridApplications, gridUsers })
            {
                g.MultiSelect = true;
                g.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            }

            gridAdmitted.ReadOnly = true;
            gridAdmitted.AllowUserToAddRows = false;
            gridAdmitted.AllowUserToDeleteRows = false;
            gridAdmitted.MultiSelect = false;
            gridAdmitted.SelectionMode = DataGridViewSelectionMode.FullRowSelect;

            cmbStuSpeciality.DataSource = _ds.Специальность;
            cmbStuSpeciality.DisplayMember = "Название_специальности";

            if (gridUsers.Columns.Contains("Пароль"))
                gridUsers.Columns["Пароль"].Visible = false;
        }

        private void btnSaveAll_Click(object sender, EventArgs e)
        {
            try
            {
                Validate();
                DataGridViewBindingFlush.FlushDataGridViews(this);

                if (!_ds.HasChanges())
                {
                    MessageBox.Show("Нет изменений для сохранения.", "Сохранение", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }

                _store.Save(_ds);
                RefreshAdmittedList();
                MessageBox.Show("Данные сохранены.", "Сохранение", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка сохранения: " + ex.Message, "Сохранение", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnExitApp_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnDeleteSelected_Click(object sender, EventArgs e)
        {
            var grid = GetGridForSelectedTab();
            if (grid == null)
                return;

            var rows = CollectBoundDataRows(grid);
            if (rows.Count == 0)
            {
                MessageBox.Show("Выберите строку в таблице активной вкладки.", "Удаление", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            if (MessageBox.Show(
                    $"Удалить выбранные записи ({rows.Count})? Изменения попадут в базу после нажатия «Сохранить».",
                    "Удаление",
                    MessageBoxButtons.YesNo,
                    MessageBoxIcon.Question) != DialogResult.Yes)
                return;

            foreach (var row in rows)
            {
                if (!TryDeleteRow(row))
                    return;
            }

            MessageBox.Show("Строки помечены на удаление. Нажмите «Сохранить», чтобы применить в базе данных.", "Удаление", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private DataGridView GetGridForSelectedTab()
        {
            var tab = tabAdminInner.SelectedTab;
            if (tab == tabApplicants) return gridApplicants;
            if (tab == tabStudents) return gridStudents;
            if (tab == tabSpecialitiesAdmin) return gridSpecialitiesAdmin;
            if (tab == tabApplications) return gridApplications;
            if (tab == tabUsers) return gridUsers;
            return null;
        }

        private static List<DataRow> CollectBoundDataRows(DataGridView grid)
        {
            var set = new HashSet<DataRow>();
            if (grid.SelectedRows.Count > 0)
            {
                foreach (DataGridViewRow gr in grid.SelectedRows)
                {
                    if (gr.IsNewRow)
                        continue;
                    if (gr.DataBoundItem is DataRowView drv)
                        set.Add(drv.Row);
                }
            }
            else if (grid.CurrentRow != null && !grid.CurrentRow.IsNewRow && grid.CurrentRow.DataBoundItem is DataRowView cur)
            {
                set.Add(cur.Row);
            }

            return new List<DataRow>(set);
        }

        private bool TryDeleteRow(DataRow row)
        {
            try
            {
                switch (row)
                {
                    case АбитуриентыDataSet.РегистрацияRow reg:
                        if (string.Equals((reg.Логин ?? "").Trim(), (_session.Login ?? "").Trim(), StringComparison.OrdinalIgnoreCase))
                        {
                            MessageBox.Show("Нельзя удалить учётную запись, под которой вы вошли.", "Удаление", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            return false;
                        }
                        reg.Delete();
                        break;
                    case АбитуриентыDataSet.АбитуриентыRow ap:
                        foreach (var child in ap.GetПодача_заявленийRows())
                            child.Delete();
                        ap.Delete();
                        break;
                    case АбитуриентыDataSet.СпециальностьRow sp:
                        foreach (var child in sp.GetПодача_заявленийRows())
                            child.Delete();
                        foreach (var st in sp.GetСтудентыRows())
                            st.Delete();
                        sp.Delete();
                        break;
                    case АбитуриентыDataSet.СтудентыRow stu:
                        stu.Delete();
                        break;
                    case АбитуриентыDataSet.Подача_заявленийRow app:
                        app.Delete();
                        break;
                    default:
                        row.Delete();
                        break;
                }
                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Не удалось удалить: " + ex.Message, "Удаление", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
        }

        private void btnAddStudent_Click(object sender, EventArgs e)
        {
            var fam = (txtStuFam.Text ?? "").Trim();
            var name = (txtStuName.Text ?? "").Trim();
            var otch = (txtStuOtch.Text ?? "").Trim();

            if (fam.Length == 0 || name.Length == 0)
            {
                MessageBox.Show("Укажите фамилию и имя.", "Студенты", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            АбитуриентыDataSet.СпециальностьRow specRow = null;
            if (cmbStuSpeciality.SelectedItem is DataRowView drv)
                specRow = (АбитуриентыDataSet.СпециальностьRow)drv.Row;

            if (specRow == null)
            {
                MessageBox.Show("Выберите специальность из списка.", "Студенты", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                _ds.Студенты.AddСтудентыRow(fam, name, otch, specRow);
                txtStuFam.Text = "";
                txtStuName.Text = "";
                txtStuOtch.Text = "";
            }
            catch (Exception ex)
            {
                MessageBox.Show("Не удалось добавить: " + ex.Message, "Студенты", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnAddSpeciality_Click(object sender, EventArgs e)
        {
            var n = (txtSpecName.Text ?? "").Trim();
            var dur = (txtSpecDuration.Text ?? "").Trim();
            var pass = (txtSpecPass.Text ?? "").Trim();

            if (n.Length == 0)
            {
                MessageBox.Show("Введите название специальности.", "Специальности", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            foreach (АбитуриентыDataSet.СпециальностьRow r in _ds.Специальность.Rows)
            {
                if (string.Equals((r.Название_специальности ?? "").Trim(), n, StringComparison.OrdinalIgnoreCase))
                {
                    MessageBox.Show("Такая специальность уже есть.", "Специальности", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
            }

            try
            {
                _ds.Специальность.AddСпециальностьRow(n, dur, pass);
                txtSpecName.Text = "";
                txtSpecDuration.Text = "";
                txtSpecPass.Text = "";
                cmbStuSpeciality.DataSource = null;
                cmbStuSpeciality.DataSource = _ds.Специальность;
                cmbStuSpeciality.DisplayMember = "Название_специальности";
            }
            catch (Exception ex)
            {
                MessageBox.Show("Не удалось добавить: " + ex.Message, "Специальности", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnAddUser_Click(object sender, EventArgs e)
        {
            var login = (txtNewLogin.Text ?? "").Trim();
            var pass = txtNewPassword.Text ?? "";
            var roleLabel = (cmbNewRole.SelectedItem ?? "").ToString();

            UserRoleKind kind;
            if (roleLabel == "Администратор")
                kind = UserRoleKind.Administrator;
            else if (roleLabel == "Пользователь")
                kind = UserRoleKind.User;
            else
            {
                MessageBox.Show("Выберите роль.", "Пользователи", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (login.Length == 0 || pass.Length == 0)
            {
                MessageBox.Show("Заполните логин и пароль.", "Пользователи", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            foreach (АбитуриентыDataSet.РегистрацияRow r in _ds.Регистрация.Rows)
            {
                if (string.Equals((r.Логин ?? "").Trim(), login, StringComparison.OrdinalIgnoreCase))
                {
                    MessageBox.Show("Такой логин уже существует.", "Пользователи", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
            }

            var storedRole = UserRoleParser.ToStoredValue(kind);
            _ds.Регистрация.AddРегистрацияRow(login, Security.PasswordHasher.Hash(pass), storedRole);
            txtNewLogin.Text = "";
            txtNewPassword.Text = "";
        }
    }
}
