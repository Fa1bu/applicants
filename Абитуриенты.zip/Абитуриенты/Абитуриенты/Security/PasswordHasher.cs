using System;
using System.Security.Cryptography;
using System.Text;

namespace Абитуриенты.Security
{
    internal static class PasswordHasher
    {
        public static string Hash(string password)
        {
            if (password == null) password = "";

            using (var sha = SHA256.Create())
            {
                var bytes = Encoding.UTF8.GetBytes(password);
                var hash = sha.ComputeHash(bytes);
                return Convert.ToBase64String(hash);
            }
        }

        public static bool Verify(string password, string expectedHashBase64)
        {
            if (expectedHashBase64 == null) return false;
            return string.Equals(Hash(password), expectedHashBase64, StringComparison.Ordinal);
        }
    }
}

