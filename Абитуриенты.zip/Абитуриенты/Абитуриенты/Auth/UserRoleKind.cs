using System;

namespace Абитуриенты.Auth
{
    /// <summary>
    /// Нормализованная роль после входа (не зависит от того, как строка хранится в Access).
    /// </summary>
    public enum UserRoleKind
    {
        Unknown = 0,
        Administrator = 1,
        User = 2
    }

    public static class UserRoleParser
    {
        public static UserRoleKind Parse(string roleFromDb)
        {
            var s = (roleFromDb ?? "").Trim();
            if (s.Length == 0)
                return UserRoleKind.Unknown;

            var lower = s.ToLowerInvariant();

            if (lower == "admin" || lower == "administrator" || lower == "админ" ||
                s.Equals("Администратор", StringComparison.OrdinalIgnoreCase))
                return UserRoleKind.Administrator;

            if (lower == "user" || lower == "users" ||
                s.Equals("Пользователь", StringComparison.OrdinalIgnoreCase))
                return UserRoleKind.User;

            return UserRoleKind.Unknown;
        }

        /// <summary>Строка для сохранения в таблицу Регистрация (латиница, как в коде).</summary>
        public static string ToStoredValue(UserRoleKind kind)
        {
            switch (kind)
            {
                case UserRoleKind.Administrator: return "Admin";
                case UserRoleKind.User: return "User";
                default: return "";
            }
        }

        public static string ToDisplayName(UserRoleKind kind)
        {
            switch (kind)
            {
                case UserRoleKind.Administrator: return "Администратор";
                case UserRoleKind.User: return "Пользователь";
                default: return "—";
            }
        }
    }
}
