namespace Абитуриенты.Auth
{
    public sealed class UserSession
    {
        public UserSession(string login, string roleRaw)
        {
            Login = login ?? "";
            RoleRaw = roleRaw ?? "";
            RoleKind = UserRoleParser.Parse(RoleRaw);
        }

        public string Login { get; }
        /// <summary>Как в базе (может быть «Admin» или «Администратор» и т.п.).</summary>
        public string RoleRaw { get; }

        public UserRoleKind RoleKind { get; }

        public bool IsAdmin => RoleKind == UserRoleKind.Administrator;
        public bool IsUser => RoleKind == UserRoleKind.User;
    }
}
