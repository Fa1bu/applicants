using System;
using System.Data;
using System.Linq;
using System.Windows.Forms;
using Абитуриенты.Data;
using Абитуриенты.Infrastructure;
using Абитуриенты.Security;

namespace Абитуриенты.Auth
{
    /// <summary>
    /// Форма авторизации (логин и пароль по таблице «Регистрация»).
    /// </summary>
    public partial class AuthorizationForm : Form
    {
        private readonly DataStore _store;
        private readonly АбитуриентыDataSet _ds;

        public AuthorizationForm(DataStore store, АбитуриентыDataSet ds)
        {
            _store = store ?? throw new ArgumentNullException(nameof(store));
            _ds = ds ?? throw new ArgumentNullException(nameof(ds));

            InitializeComponent();
            AppTheme.Apply(this);
        }

        public UserSession Session { get; private set; }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            var login = (txtLogin.Text ?? "").Trim();
            var password = txtPassword.Text ?? "";

            if (login.Length == 0)
            {
                MessageBox.Show("Введите логин.", "Авторизация", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            var row = _ds.Регистрация
                .Cast<DataRow>()
                .Select(r => (АбитуриентыDataSet.РегистрацияRow)r)
                .FirstOrDefault(r => string.Equals((r.Логин ?? "").Trim(), login, StringComparison.OrdinalIgnoreCase));

            var passwordOk = row != null &&
                             (PasswordHasher.Verify(password, row.Пароль) ||
                              string.Equals(password, row.Пароль ?? "", StringComparison.Ordinal));

            if (!passwordOk)
            {
                MessageBox.Show("Неверный логин или пароль.", "Авторизация", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            var session = new UserSession(row.Логин, row.Роль);
            if (session.RoleKind == UserRoleKind.Unknown)
            {
                MessageBox.Show(
                    "Роль в базе не распознана: «" + (row.Роль ?? "") + "».\n" +
                    "Допустимо: Администратор / Пользователь или Admin / User.",
                    "Авторизация",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
                Session = null;
                return;
            }

            Session = session;
            DialogResult = DialogResult.OK;
            Close();
        }

        private void btnRegister_Click(object sender, EventArgs e)
        {
            var login = (txtLogin.Text ?? "").Trim();
            var password = txtPassword.Text ?? "";

            if (login.Length == 0)
            {
                MessageBox.Show("Введите логин для регистрации.", "Регистрация", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (password.Length < 4)
            {
                MessageBox.Show("Пароль должен содержать минимум 4 символа.", "Регистрация", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            var exists = _ds.Регистрация
                .Cast<DataRow>()
                .Select(r => (АбитуриентыDataSet.РегистрацияRow)r)
                .Any(r => string.Equals((r.Логин ?? "").Trim(), login, StringComparison.OrdinalIgnoreCase));

            if (exists)
            {
                MessageBox.Show("Пользователь с таким логином уже существует.", "Регистрация", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                _ds.Регистрация.AddРегистрацияRow(
                    login,
                    PasswordHasher.Hash(password),
                    UserRoleParser.ToStoredValue(UserRoleKind.User));

                _store.Save(_ds);
                MessageBox.Show("Регистрация успешна. Теперь можно войти.", "Регистрация", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Не удалось зарегистрироваться: " + ex.Message, "Регистрация", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
            Close();
        }
    }
}
