using System.Drawing;
using System.Windows.Forms;

namespace Абитуриенты.Infrastructure
{
    internal static class AppTheme
    {
        public static readonly Color Bg = Color.FromArgb(245, 247, 250);
        public static readonly Color Card = Color.FromArgb(255, 255, 255);
        public static readonly Color Muted = Color.FromArgb(99, 115, 129);
        public static readonly Color Text = Color.FromArgb(35, 45, 55);
        public static readonly Color Accent = Color.FromArgb(37, 99, 235);

        public static void Apply(Form form)
        {
            form.BackColor = Bg;
            form.ForeColor = Text;
            form.Font = new Font("Segoe UI", 10f);

            ApplyRecursive(form);
        }

        private static void ApplyRecursive(Control root)
        {
            foreach (Control c in root.Controls)
            {
                if (c is Panel || c is GroupBox)
                {
                    c.BackColor = Card;
                    c.ForeColor = Text;
                }

                if (c is Label)
                {
                    c.ForeColor = Text;
                }

                if (c is TextBox tb)
                {
                    tb.BorderStyle = BorderStyle.FixedSingle;
                    tb.BackColor = Color.White;
                    tb.ForeColor = Text;
                }

                if (c is ComboBox cb)
                {
                    cb.FlatStyle = FlatStyle.Flat;
                    cb.BackColor = Color.White;
                    cb.ForeColor = Text;
                }

                if (c is Button b)
                {
                    b.FlatStyle = FlatStyle.Flat;
                    b.FlatAppearance.BorderSize = 0;
                    b.BackColor = Accent;
                    b.ForeColor = Color.White;
                    b.Height = 34;
                }

                if (c is DataGridView grid)
                {
                    grid.BackgroundColor = Card;
                    grid.BorderStyle = BorderStyle.None;
                    grid.EnableHeadersVisualStyles = false;
                    grid.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(230, 236, 243);
                    grid.ColumnHeadersDefaultCellStyle.ForeColor = Text;
                    grid.DefaultCellStyle.BackColor = Color.White;
                    grid.DefaultCellStyle.ForeColor = Text;
                    grid.DefaultCellStyle.SelectionBackColor = Color.FromArgb(219, 234, 254);
                    grid.DefaultCellStyle.SelectionForeColor = Color.FromArgb(30, 64, 175);
                    grid.RowHeadersVisible = false;
                    grid.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
                    grid.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
                    grid.MultiSelect = false;
                }

                ApplyRecursive(c);
            }
        }
    }
}

