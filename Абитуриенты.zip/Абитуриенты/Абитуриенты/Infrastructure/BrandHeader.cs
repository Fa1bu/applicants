using System.Drawing;
using System.Windows.Forms;

namespace Абитуриенты.Infrastructure
{
    internal static class BrandHeader
    {
        public const string Institution = "Российский техникум";
        public const string Phone = "89508238522";
        public const string Email = "belykh_2007@bk.ru";

        public static void Apply(Label lblInstitution, Label lblContacts)
        {
            lblInstitution.Text = Institution;
            lblInstitution.Font = new Font("Segoe UI Semibold", 15.75F, FontStyle.Bold);
            lblInstitution.ForeColor = AppTheme.Text;
            lblInstitution.AutoSize = true;

            lblContacts.Text = "Тел. " + Phone + "\r\n" + Email;
            lblContacts.Font = new Font("Segoe UI", 10F);
            lblContacts.ForeColor = AppTheme.Muted;
            lblContacts.TextAlign = ContentAlignment.TopRight;
            lblContacts.AutoSize = true;
        }
    }
}
