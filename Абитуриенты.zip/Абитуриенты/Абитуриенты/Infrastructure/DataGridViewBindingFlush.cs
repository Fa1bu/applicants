using System.Windows.Forms;

namespace Абитуриенты.Infrastructure
{
    /// <summary>
    /// Переносит несохранённые правки из ячеек DataGridView в привязанный DataSet (иначе Save не видит изменений).
    /// </summary>
    internal static class DataGridViewBindingFlush
    {
        public static void FlushDataGridViews(Control root)
        {
            if (root == null)
                return;

            if (root is ContainerControl container)
                container.ValidateChildren();

            foreach (Control child in root.Controls)
                FlushDataGridViews(child);

            if (root is DataGridView grid)
                FlushOne(grid);
        }

        private static void FlushOne(DataGridView grid)
        {
            if (grid.DataSource == null)
                return;

            grid.EndEdit();

            if (grid.IsCurrentCellDirty)
                grid.CommitEdit(DataGridViewDataErrorContexts.Commit);

            var ctx = grid.BindingContext;
            if (ctx == null && grid.TopLevelControl is Control top)
                ctx = top.BindingContext;
            if (ctx == null)
                return;

            if (ctx[grid.DataSource] is CurrencyManager cm)
                cm.EndCurrentEdit();
        }
    }
}
