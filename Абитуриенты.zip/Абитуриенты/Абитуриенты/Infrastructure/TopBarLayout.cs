using System.Drawing;
using System.Windows.Forms;

namespace Абитуриенты.Infrastructure
{
    /// <summary>
    /// Верхняя панель: слева навигация и подпись пользователя, справа кнопки действий (без перекрытия).
    /// </summary>
    internal static class TopBarLayout
    {
        public const int BarHeight = 88;

        public static FlowLayoutPanel Configure(Panel panelTop, Label lblUser, params Button[] actionButtons)
        {
            panelTop.SuspendLayout();
            panelTop.Height = BarHeight;
            panelTop.Padding = new Padding(16, 8, 16, 8);

            lblUser.Dock = DockStyle.None;
            lblUser.AutoSize = true;
            lblUser.Anchor = AnchorStyles.Left | AnchorStyles.Bottom;
            lblUser.Location = new Point(16, 56);

            var actions = GetOrCreateActionsPanel(panelTop);
            actions.Controls.Clear();
            foreach (var btn in actionButtons)
            {
                if (btn == null)
                    continue;
                if (btn.Parent != null && btn.Parent != actions)
                    btn.Parent.Controls.Remove(btn);

                btn.Dock = DockStyle.None;
                btn.AutoSize = false;
                btn.Width = 128;
                btn.Height = 32;
                btn.Margin = new Padding(8, 0, 0, 0);
                actions.Controls.Add(btn);
            }

            var nav = GetOrCreateNavPanel(panelTop);
            nav.Controls.Clear();
            nav.BringToFront();
            actions.BringToFront();

            panelTop.ResumeLayout(true);
            return nav;
        }

        private static FlowLayoutPanel GetOrCreateActionsPanel(Panel panelTop)
        {
            foreach (Control c in panelTop.Controls)
            {
                if (c.Name == "panelTopActions" && c is FlowLayoutPanel existing)
                    return existing;
            }

            var actions = new FlowLayoutPanel
            {
                Name = "panelTopActions",
                Dock = DockStyle.Right,
                AutoSize = true,
                AutoSizeMode = AutoSizeMode.GrowAndShrink,
                FlowDirection = FlowDirection.LeftToRight,
                WrapContents = false,
                Padding = new Padding(0, 2, 0, 0)
            };
            panelTop.Controls.Add(actions);
            return actions;
        }

        private static FlowLayoutPanel GetOrCreateNavPanel(Panel panelTop)
        {
            foreach (Control c in panelTop.Controls)
            {
                if (c.Name == "panelNavButtons" && c is FlowLayoutPanel existing)
                    return existing;
            }

            var nav = new FlowLayoutPanel
            {
                Name = "panelNavButtons",
                Dock = DockStyle.Top,
                Height = 36,
                AutoSize = false,
                WrapContents = false,
                FlowDirection = FlowDirection.LeftToRight,
                Padding = new Padding(0, 0, 8, 0)
            };
            panelTop.Controls.Add(nav);
            return nav;
        }
    }
}
