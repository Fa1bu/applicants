namespace Абитуриенты
{
    partial class AdminForm
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.Panel panelBrand;
        private System.Windows.Forms.TableLayoutPanel tableBrand;
        private System.Windows.Forms.Label lblInstitution;
        private System.Windows.Forms.Label lblContacts;
        private System.Windows.Forms.Panel panelTop;
        private System.Windows.Forms.Label lblUser;
        private System.Windows.Forms.Button btnSaveAll;
        private System.Windows.Forms.Button btnDeleteSelected;
        private System.Windows.Forms.Button btnExitApp;
        private System.Windows.Forms.TabControl tabAdminInner;
        private System.Windows.Forms.TabPage tabApplicants;
        private System.Windows.Forms.TabPage tabStudents;
        private System.Windows.Forms.TabPage tabSpecialitiesAdmin;
        private System.Windows.Forms.TabPage tabApplications;
        private System.Windows.Forms.TabPage tabAdmitted;
        private System.Windows.Forms.TabPage tabUsers;
        private System.Windows.Forms.DataGridView gridApplicants;
        private System.Windows.Forms.DataGridView gridStudents;
        private System.Windows.Forms.DataGridView gridSpecialitiesAdmin;
        private System.Windows.Forms.DataGridView gridApplications;
        private System.Windows.Forms.DataGridView gridAdmitted;
        private System.Windows.Forms.DataGridView gridUsers;
        private System.Windows.Forms.Panel panelAddStudent;
        private System.Windows.Forms.TextBox txtStuFam;
        private System.Windows.Forms.TextBox txtStuName;
        private System.Windows.Forms.TextBox txtStuOtch;
        private System.Windows.Forms.ComboBox cmbStuSpeciality;
        private System.Windows.Forms.Button btnAddStudent;
        private System.Windows.Forms.Label lblStuFam;
        private System.Windows.Forms.Label lblStuName;
        private System.Windows.Forms.Label lblStuOtch;
        private System.Windows.Forms.Label lblStuSpec;
        private System.Windows.Forms.Panel panelAddSpeciality;
        private System.Windows.Forms.TextBox txtSpecName;
        private System.Windows.Forms.TextBox txtSpecDuration;
        private System.Windows.Forms.TextBox txtSpecPass;
        private System.Windows.Forms.Button btnAddSpeciality;
        private System.Windows.Forms.Label lblSpecName;
        private System.Windows.Forms.Label lblSpecDuration;
        private System.Windows.Forms.Label lblSpecPass;
        private System.Windows.Forms.Panel panelAddUser;
        private System.Windows.Forms.TextBox txtNewLogin;
        private System.Windows.Forms.TextBox txtNewPassword;
        private System.Windows.Forms.ComboBox cmbNewRole;
        private System.Windows.Forms.Button btnAddUser;
        private System.Windows.Forms.Label lblNewLogin;
        private System.Windows.Forms.Label lblNewPassword;
        private System.Windows.Forms.Label lblNewRole;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        private void InitializeComponent()
        {
            this.panelBrand = new System.Windows.Forms.Panel();
            this.tableBrand = new System.Windows.Forms.TableLayoutPanel();
            this.lblInstitution = new System.Windows.Forms.Label();
            this.lblContacts = new System.Windows.Forms.Label();
            this.panelTop = new System.Windows.Forms.Panel();
            this.btnExitApp = new System.Windows.Forms.Button();
            this.btnSaveAll = new System.Windows.Forms.Button();
            this.btnDeleteSelected = new System.Windows.Forms.Button();
            this.lblUser = new System.Windows.Forms.Label();
            this.tabAdminInner = new System.Windows.Forms.TabControl();
            this.tabApplicants = new System.Windows.Forms.TabPage();
            this.gridApplicants = new System.Windows.Forms.DataGridView();
            this.tabStudents = new System.Windows.Forms.TabPage();
            this.gridStudents = new System.Windows.Forms.DataGridView();
            this.panelAddStudent = new System.Windows.Forms.Panel();
            this.btnAddStudent = new System.Windows.Forms.Button();
            this.cmbStuSpeciality = new System.Windows.Forms.ComboBox();
            this.txtStuOtch = new System.Windows.Forms.TextBox();
            this.txtStuName = new System.Windows.Forms.TextBox();
            this.txtStuFam = new System.Windows.Forms.TextBox();
            this.lblStuSpec = new System.Windows.Forms.Label();
            this.lblStuOtch = new System.Windows.Forms.Label();
            this.lblStuName = new System.Windows.Forms.Label();
            this.lblStuFam = new System.Windows.Forms.Label();
            this.tabSpecialitiesAdmin = new System.Windows.Forms.TabPage();
            this.gridSpecialitiesAdmin = new System.Windows.Forms.DataGridView();
            this.panelAddSpeciality = new System.Windows.Forms.Panel();
            this.btnAddSpeciality = new System.Windows.Forms.Button();
            this.txtSpecPass = new System.Windows.Forms.TextBox();
            this.txtSpecDuration = new System.Windows.Forms.TextBox();
            this.txtSpecName = new System.Windows.Forms.TextBox();
            this.lblSpecPass = new System.Windows.Forms.Label();
            this.lblSpecDuration = new System.Windows.Forms.Label();
            this.lblSpecName = new System.Windows.Forms.Label();
            this.tabApplications = new System.Windows.Forms.TabPage();
            this.gridApplications = new System.Windows.Forms.DataGridView();
            this.tabAdmitted = new System.Windows.Forms.TabPage();
            this.gridAdmitted = new System.Windows.Forms.DataGridView();
            this.tabUsers = new System.Windows.Forms.TabPage();
            this.gridUsers = new System.Windows.Forms.DataGridView();
            this.panelAddUser = new System.Windows.Forms.Panel();
            this.btnAddUser = new System.Windows.Forms.Button();
            this.cmbNewRole = new System.Windows.Forms.ComboBox();
            this.txtNewPassword = new System.Windows.Forms.TextBox();
            this.txtNewLogin = new System.Windows.Forms.TextBox();
            this.lblNewRole = new System.Windows.Forms.Label();
            this.lblNewPassword = new System.Windows.Forms.Label();
            this.lblNewLogin = new System.Windows.Forms.Label();
            this.panelBrand.SuspendLayout();
            this.tableBrand.SuspendLayout();
            this.panelTop.SuspendLayout();
            this.tabAdminInner.SuspendLayout();
            this.tabApplicants.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridApplicants)).BeginInit();
            this.tabStudents.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridStudents)).BeginInit();
            this.panelAddStudent.SuspendLayout();
            this.tabSpecialitiesAdmin.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridSpecialitiesAdmin)).BeginInit();
            this.panelAddSpeciality.SuspendLayout();
            this.tabApplications.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridApplications)).BeginInit();
            this.tabAdmitted.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridAdmitted)).BeginInit();
            this.tabUsers.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridUsers)).BeginInit();
            this.panelAddUser.SuspendLayout();
            this.SuspendLayout();
            // 
            // panelBrand
            // 
            this.panelBrand.Controls.Add(this.tableBrand);
            this.panelBrand.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelBrand.Location = new System.Drawing.Point(0, 0);
            this.panelBrand.Name = "panelBrand";
            this.panelBrand.Padding = new System.Windows.Forms.Padding(8);
            this.panelBrand.Size = new System.Drawing.Size(1257, 76);
            this.panelBrand.TabIndex = 0;
            // 
            // tableBrand
            // 
            this.tableBrand.ColumnCount = 2;
            this.tableBrand.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 55F));
            this.tableBrand.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 45F));
            this.tableBrand.Controls.Add(this.lblInstitution, 0, 0);
            this.tableBrand.Controls.Add(this.lblContacts, 1, 0);
            this.tableBrand.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableBrand.Location = new System.Drawing.Point(8, 8);
            this.tableBrand.Name = "tableBrand";
            this.tableBrand.RowCount = 1;
            this.tableBrand.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableBrand.Size = new System.Drawing.Size(1241, 60);
            this.tableBrand.TabIndex = 0;
            // 
            // lblInstitution
            // 
            this.lblInstitution.AutoSize = true;
            this.lblInstitution.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblInstitution.Location = new System.Drawing.Point(3, 0);
            this.lblInstitution.Name = "lblInstitution";
            this.lblInstitution.Size = new System.Drawing.Size(676, 60);
            this.lblInstitution.TabIndex = 0;
            this.lblInstitution.Text = "Российский техникум";
            this.lblInstitution.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblContacts
            // 
            this.lblContacts.AutoSize = true;
            this.lblContacts.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblContacts.Location = new System.Drawing.Point(685, 0);
            this.lblContacts.Name = "lblContacts";
            this.lblContacts.Size = new System.Drawing.Size(553, 60);
            this.lblContacts.TabIndex = 1;
            this.lblContacts.Text = "Тел. 89508238522\r\nbelykh_2007@bk.ru";
            this.lblContacts.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panelTop
            // 
            this.panelTop.Controls.Add(this.btnExitApp);
            this.panelTop.Controls.Add(this.btnSaveAll);
            this.panelTop.Controls.Add(this.btnDeleteSelected);
            this.panelTop.Controls.Add(this.lblUser);
            this.panelTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelTop.Location = new System.Drawing.Point(0, 76);
            this.panelTop.Name = "panelTop";
            this.panelTop.Padding = new System.Windows.Forms.Padding(16, 10, 16, 10);
            this.panelTop.Size = new System.Drawing.Size(1257, 88);
            this.panelTop.TabIndex = 1;
            // 
            // btnExitApp
            // 
            this.btnExitApp.Location = new System.Drawing.Point(0, 0);
            this.btnExitApp.Name = "btnExitApp";
            this.btnExitApp.Size = new System.Drawing.Size(183, 32);
            this.btnExitApp.TabIndex = 2;
            this.btnExitApp.Text = "Выход";
            this.btnExitApp.UseVisualStyleBackColor = true;
            this.btnExitApp.Click += new System.EventHandler(this.btnExitApp_Click);
            // 
            // btnSaveAll
            // 
            this.btnSaveAll.Location = new System.Drawing.Point(0, 0);
            this.btnSaveAll.Name = "btnSaveAll";
            this.btnSaveAll.Size = new System.Drawing.Size(183, 32);
            this.btnSaveAll.TabIndex = 1;
            this.btnSaveAll.Text = "Сохранить";
            this.btnSaveAll.UseVisualStyleBackColor = true;
            this.btnSaveAll.Click += new System.EventHandler(this.btnSaveAll_Click);
            // 
            // btnDeleteSelected
            // 
            this.btnDeleteSelected.Location = new System.Drawing.Point(0, 0);
            this.btnDeleteSelected.Name = "btnDeleteSelected";
            this.btnDeleteSelected.Size = new System.Drawing.Size(183, 32);
            this.btnDeleteSelected.TabIndex = 3;
            this.btnDeleteSelected.Text = "Удалить";
            this.btnDeleteSelected.UseVisualStyleBackColor = true;
            this.btnDeleteSelected.Click += new System.EventHandler(this.btnDeleteSelected_Click);
            // 
            // lblUser
            // 
            this.lblUser.AutoSize = true;
            this.lblUser.Location = new System.Drawing.Point(16, 56);
            this.lblUser.Name = "lblUser";
            this.lblUser.Size = new System.Drawing.Size(112, 16);
            this.lblUser.TabIndex = 0;
            this.lblUser.Text = "Пользователь: -";
            // 
            // tabAdminInner
            // 
            this.tabAdminInner.Controls.Add(this.tabApplicants);
            this.tabAdminInner.Controls.Add(this.tabStudents);
            this.tabAdminInner.Controls.Add(this.tabSpecialitiesAdmin);
            this.tabAdminInner.Controls.Add(this.tabApplications);
            this.tabAdminInner.Controls.Add(this.tabAdmitted);
            this.tabAdminInner.Controls.Add(this.tabUsers);
            this.tabAdminInner.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabAdminInner.Location = new System.Drawing.Point(0, 128);
            this.tabAdminInner.Name = "tabAdminInner";
            this.tabAdminInner.SelectedIndex = 0;
            this.tabAdminInner.Size = new System.Drawing.Size(1257, 619);
            this.tabAdminInner.TabIndex = 2;
            // 
            // tabApplicants
            // 
            this.tabApplicants.Controls.Add(this.gridApplicants);
            this.tabApplicants.Location = new System.Drawing.Point(4, 25);
            this.tabApplicants.Name = "tabApplicants";
            this.tabApplicants.Padding = new System.Windows.Forms.Padding(11);
            this.tabApplicants.Size = new System.Drawing.Size(1249, 590);
            this.tabApplicants.TabIndex = 0;
            this.tabApplicants.Text = "Абитуриенты";
            this.tabApplicants.UseVisualStyleBackColor = true;
            // 
            // gridApplicants
            // 
            this.gridApplicants.ColumnHeadersHeight = 29;
            this.gridApplicants.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gridApplicants.Location = new System.Drawing.Point(11, 11);
            this.gridApplicants.Name = "gridApplicants";
            this.gridApplicants.RowHeadersWidth = 51;
            this.gridApplicants.Size = new System.Drawing.Size(1227, 568);
            this.gridApplicants.TabIndex = 0;
            // 
            // tabStudents
            // 
            this.tabStudents.Controls.Add(this.gridStudents);
            this.tabStudents.Controls.Add(this.panelAddStudent);
            this.tabStudents.Location = new System.Drawing.Point(4, 25);
            this.tabStudents.Name = "tabStudents";
            this.tabStudents.Padding = new System.Windows.Forms.Padding(11);
            this.tabStudents.Size = new System.Drawing.Size(1249, 590);
            this.tabStudents.TabIndex = 1;
            this.tabStudents.Text = "Студенты";
            this.tabStudents.UseVisualStyleBackColor = true;
            // 
            // gridStudents
            // 
            this.gridStudents.ColumnHeadersHeight = 29;
            this.gridStudents.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gridStudents.Location = new System.Drawing.Point(11, 131);
            this.gridStudents.Name = "gridStudents";
            this.gridStudents.RowHeadersWidth = 51;
            this.gridStudents.Size = new System.Drawing.Size(1227, 448);
            this.gridStudents.TabIndex = 1;
            // 
            // panelAddStudent
            // 
            this.panelAddStudent.Controls.Add(this.btnAddStudent);
            this.panelAddStudent.Controls.Add(this.cmbStuSpeciality);
            this.panelAddStudent.Controls.Add(this.txtStuOtch);
            this.panelAddStudent.Controls.Add(this.txtStuName);
            this.panelAddStudent.Controls.Add(this.txtStuFam);
            this.panelAddStudent.Controls.Add(this.lblStuSpec);
            this.panelAddStudent.Controls.Add(this.lblStuOtch);
            this.panelAddStudent.Controls.Add(this.lblStuName);
            this.panelAddStudent.Controls.Add(this.lblStuFam);
            this.panelAddStudent.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelAddStudent.Location = new System.Drawing.Point(11, 11);
            this.panelAddStudent.Name = "panelAddStudent";
            this.panelAddStudent.Padding = new System.Windows.Forms.Padding(8);
            this.panelAddStudent.Size = new System.Drawing.Size(1227, 120);
            this.panelAddStudent.TabIndex = 0;
            // 
            // btnAddStudent
            // 
            this.btnAddStudent.Location = new System.Drawing.Point(1040, 52);
            this.btnAddStudent.Name = "btnAddStudent";
            this.btnAddStudent.Size = new System.Drawing.Size(170, 36);
            this.btnAddStudent.TabIndex = 8;
            this.btnAddStudent.Text = "Добавить студента";
            this.btnAddStudent.UseVisualStyleBackColor = true;
            this.btnAddStudent.Click += new System.EventHandler(this.btnAddStudent_Click);
            // 
            // cmbStuSpeciality
            // 
            this.cmbStuSpeciality.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbStuSpeciality.FormattingEnabled = true;
            this.cmbStuSpeciality.Location = new System.Drawing.Point(700, 58);
            this.cmbStuSpeciality.Name = "cmbStuSpeciality";
            this.cmbStuSpeciality.Size = new System.Drawing.Size(320, 24);
            this.cmbStuSpeciality.TabIndex = 7;
            // 
            // txtStuOtch
            // 
            this.txtStuOtch.Location = new System.Drawing.Point(472, 58);
            this.txtStuOtch.Name = "txtStuOtch";
            this.txtStuOtch.Size = new System.Drawing.Size(200, 22);
            this.txtStuOtch.TabIndex = 6;
            // 
            // txtStuName
            // 
            this.txtStuName.Location = new System.Drawing.Point(244, 58);
            this.txtStuName.Name = "txtStuName";
            this.txtStuName.Size = new System.Drawing.Size(200, 22);
            this.txtStuName.TabIndex = 5;
            // 
            // txtStuFam
            // 
            this.txtStuFam.Location = new System.Drawing.Point(16, 58);
            this.txtStuFam.Name = "txtStuFam";
            this.txtStuFam.Size = new System.Drawing.Size(200, 22);
            this.txtStuFam.TabIndex = 4;
            // 
            // lblStuSpec
            // 
            this.lblStuSpec.AutoSize = true;
            this.lblStuSpec.Location = new System.Drawing.Point(697, 28);
            this.lblStuSpec.Name = "lblStuSpec";
            this.lblStuSpec.Size = new System.Drawing.Size(108, 16);
            this.lblStuSpec.TabIndex = 3;
            this.lblStuSpec.Text = "Специальность";
            // 
            // lblStuOtch
            // 
            this.lblStuOtch.AutoSize = true;
            this.lblStuOtch.Location = new System.Drawing.Point(469, 28);
            this.lblStuOtch.Name = "lblStuOtch";
            this.lblStuOtch.Size = new System.Drawing.Size(70, 16);
            this.lblStuOtch.TabIndex = 2;
            this.lblStuOtch.Text = "Отчество";
            // 
            // lblStuName
            // 
            this.lblStuName.AutoSize = true;
            this.lblStuName.Location = new System.Drawing.Point(241, 28);
            this.lblStuName.Name = "lblStuName";
            this.lblStuName.Size = new System.Drawing.Size(33, 16);
            this.lblStuName.TabIndex = 1;
            this.lblStuName.Text = "Имя";
            // 
            // lblStuFam
            // 
            this.lblStuFam.AutoSize = true;
            this.lblStuFam.Location = new System.Drawing.Point(13, 28);
            this.lblStuFam.Name = "lblStuFam";
            this.lblStuFam.Size = new System.Drawing.Size(66, 16);
            this.lblStuFam.TabIndex = 0;
            this.lblStuFam.Text = "Фамилия";
            // 
            // tabSpecialitiesAdmin
            // 
            this.tabSpecialitiesAdmin.Controls.Add(this.gridSpecialitiesAdmin);
            this.tabSpecialitiesAdmin.Controls.Add(this.panelAddSpeciality);
            this.tabSpecialitiesAdmin.Location = new System.Drawing.Point(4, 25);
            this.tabSpecialitiesAdmin.Name = "tabSpecialitiesAdmin";
            this.tabSpecialitiesAdmin.Padding = new System.Windows.Forms.Padding(11);
            this.tabSpecialitiesAdmin.Size = new System.Drawing.Size(1249, 590);
            this.tabSpecialitiesAdmin.TabIndex = 2;
            this.tabSpecialitiesAdmin.Text = "Специальности";
            this.tabSpecialitiesAdmin.UseVisualStyleBackColor = true;
            // 
            // gridSpecialitiesAdmin
            // 
            this.gridSpecialitiesAdmin.ColumnHeadersHeight = 29;
            this.gridSpecialitiesAdmin.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gridSpecialitiesAdmin.Location = new System.Drawing.Point(11, 131);
            this.gridSpecialitiesAdmin.Name = "gridSpecialitiesAdmin";
            this.gridSpecialitiesAdmin.RowHeadersWidth = 51;
            this.gridSpecialitiesAdmin.Size = new System.Drawing.Size(1227, 448);
            this.gridSpecialitiesAdmin.TabIndex = 1;
            // 
            // panelAddSpeciality
            // 
            this.panelAddSpeciality.Controls.Add(this.btnAddSpeciality);
            this.panelAddSpeciality.Controls.Add(this.txtSpecPass);
            this.panelAddSpeciality.Controls.Add(this.txtSpecDuration);
            this.panelAddSpeciality.Controls.Add(this.txtSpecName);
            this.panelAddSpeciality.Controls.Add(this.lblSpecPass);
            this.panelAddSpeciality.Controls.Add(this.lblSpecDuration);
            this.panelAddSpeciality.Controls.Add(this.lblSpecName);
            this.panelAddSpeciality.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelAddSpeciality.Location = new System.Drawing.Point(11, 11);
            this.panelAddSpeciality.Name = "panelAddSpeciality";
            this.panelAddSpeciality.Padding = new System.Windows.Forms.Padding(8);
            this.panelAddSpeciality.Size = new System.Drawing.Size(1227, 120);
            this.panelAddSpeciality.TabIndex = 0;
            // 
            // btnAddSpeciality
            // 
            this.btnAddSpeciality.Location = new System.Drawing.Point(1040, 52);
            this.btnAddSpeciality.Name = "btnAddSpeciality";
            this.btnAddSpeciality.Size = new System.Drawing.Size(170, 36);
            this.btnAddSpeciality.TabIndex = 6;
            this.btnAddSpeciality.Text = "Добавить специальность";
            this.btnAddSpeciality.UseVisualStyleBackColor = true;
            this.btnAddSpeciality.Click += new System.EventHandler(this.btnAddSpeciality_Click);
            // 
            // txtSpecPass
            // 
            this.txtSpecPass.Location = new System.Drawing.Point(700, 58);
            this.txtSpecPass.Name = "txtSpecPass";
            this.txtSpecPass.Size = new System.Drawing.Size(120, 22);
            this.txtSpecPass.TabIndex = 5;
            // 
            // txtSpecDuration
            // 
            this.txtSpecDuration.Location = new System.Drawing.Point(472, 58);
            this.txtSpecDuration.Name = "txtSpecDuration";
            this.txtSpecDuration.Size = new System.Drawing.Size(200, 22);
            this.txtSpecDuration.TabIndex = 4;
            // 
            // txtSpecName
            // 
            this.txtSpecName.Location = new System.Drawing.Point(16, 58);
            this.txtSpecName.Name = "txtSpecName";
            this.txtSpecName.Size = new System.Drawing.Size(420, 22);
            this.txtSpecName.TabIndex = 3;
            // 
            // lblSpecPass
            // 
            this.lblSpecPass.AutoSize = true;
            this.lblSpecPass.Location = new System.Drawing.Point(697, 28);
            this.lblSpecPass.Name = "lblSpecPass";
            this.lblSpecPass.Size = new System.Drawing.Size(114, 16);
            this.lblSpecPass.TabIndex = 2;
            this.lblSpecPass.Text = "Проходной балл";
            // 
            // lblSpecDuration
            // 
            this.lblSpecDuration.AutoSize = true;
            this.lblSpecDuration.Location = new System.Drawing.Point(469, 28);
            this.lblSpecDuration.Name = "lblSpecDuration";
            this.lblSpecDuration.Size = new System.Drawing.Size(105, 16);
            this.lblSpecDuration.TabIndex = 1;
            this.lblSpecDuration.Text = "Срок обучения";
            // 
            // lblSpecName
            // 
            this.lblSpecName.AutoSize = true;
            this.lblSpecName.Location = new System.Drawing.Point(13, 28);
            this.lblSpecName.Name = "lblSpecName";
            this.lblSpecName.Size = new System.Drawing.Size(176, 16);
            this.lblSpecName.TabIndex = 0;
            this.lblSpecName.Text = "Название специальности";
            // 
            // tabApplications
            // 
            this.tabApplications.Controls.Add(this.gridApplications);
            this.tabApplications.Location = new System.Drawing.Point(4, 25);
            this.tabApplications.Name = "tabApplications";
            this.tabApplications.Padding = new System.Windows.Forms.Padding(11);
            this.tabApplications.Size = new System.Drawing.Size(1249, 590);
            this.tabApplications.TabIndex = 3;
            this.tabApplications.Text = "Заявления";
            this.tabApplications.UseVisualStyleBackColor = true;
            // 
            // gridApplications
            // 
            this.gridApplications.ColumnHeadersHeight = 29;
            this.gridApplications.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gridApplications.Location = new System.Drawing.Point(11, 11);
            this.gridApplications.Name = "gridApplications";
            this.gridApplications.RowHeadersWidth = 51;
            this.gridApplications.Size = new System.Drawing.Size(1227, 568);
            this.gridApplications.TabIndex = 0;
            // 
            // tabAdmitted
            // 
            this.tabAdmitted.Controls.Add(this.gridAdmitted);
            this.tabAdmitted.Location = new System.Drawing.Point(4, 25);
            this.tabAdmitted.Name = "tabAdmitted";
            this.tabAdmitted.Padding = new System.Windows.Forms.Padding(11);
            this.tabAdmitted.Size = new System.Drawing.Size(1249, 590);
            this.tabAdmitted.TabIndex = 4;
            this.tabAdmitted.Text = "Список поступивших";
            this.tabAdmitted.UseVisualStyleBackColor = true;
            // 
            // gridAdmitted
            // 
            this.gridAdmitted.ColumnHeadersHeight = 29;
            this.gridAdmitted.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gridAdmitted.Location = new System.Drawing.Point(11, 11);
            this.gridAdmitted.Name = "gridAdmitted";
            this.gridAdmitted.ReadOnly = true;
            this.gridAdmitted.RowHeadersWidth = 51;
            this.gridAdmitted.Size = new System.Drawing.Size(1227, 568);
            this.gridAdmitted.TabIndex = 0;
            // 
            // tabUsers
            // 
            this.tabUsers.Controls.Add(this.gridUsers);
            this.tabUsers.Controls.Add(this.panelAddUser);
            this.tabUsers.Location = new System.Drawing.Point(4, 25);
            this.tabUsers.Name = "tabUsers";
            this.tabUsers.Padding = new System.Windows.Forms.Padding(11);
            this.tabUsers.Size = new System.Drawing.Size(1249, 590);
            this.tabUsers.TabIndex = 4;
            this.tabUsers.Text = "Пользователи";
            this.tabUsers.UseVisualStyleBackColor = true;
            // 
            // gridUsers
            // 
            this.gridUsers.ColumnHeadersHeight = 29;
            this.gridUsers.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gridUsers.Location = new System.Drawing.Point(11, 122);
            this.gridUsers.Name = "gridUsers";
            this.gridUsers.RowHeadersWidth = 51;
            this.gridUsers.Size = new System.Drawing.Size(1227, 457);
            this.gridUsers.TabIndex = 1;
            // 
            // panelAddUser
            // 
            this.panelAddUser.Controls.Add(this.btnAddUser);
            this.panelAddUser.Controls.Add(this.cmbNewRole);
            this.panelAddUser.Controls.Add(this.txtNewPassword);
            this.panelAddUser.Controls.Add(this.txtNewLogin);
            this.panelAddUser.Controls.Add(this.lblNewRole);
            this.panelAddUser.Controls.Add(this.lblNewPassword);
            this.panelAddUser.Controls.Add(this.lblNewLogin);
            this.panelAddUser.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelAddUser.Location = new System.Drawing.Point(11, 11);
            this.panelAddUser.Name = "panelAddUser";
            this.panelAddUser.Padding = new System.Windows.Forms.Padding(11);
            this.panelAddUser.Size = new System.Drawing.Size(1227, 111);
            this.panelAddUser.TabIndex = 0;
            // 
            // btnAddUser
            // 
            this.btnAddUser.Location = new System.Drawing.Point(962, 48);
            this.btnAddUser.Name = "btnAddUser";
            this.btnAddUser.Size = new System.Drawing.Size(206, 38);
            this.btnAddUser.TabIndex = 6;
            this.btnAddUser.Text = "Добавить";
            this.btnAddUser.UseVisualStyleBackColor = true;
            this.btnAddUser.Click += new System.EventHandler(this.btnAddUser_Click);
            // 
            // cmbNewRole
            // 
            this.cmbNewRole.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbNewRole.FormattingEnabled = true;
            this.cmbNewRole.Items.AddRange(new object[] {
            "Администратор",
            "Пользователь"});
            this.cmbNewRole.Location = new System.Drawing.Point(624, 54);
            this.cmbNewRole.Name = "cmbNewRole";
            this.cmbNewRole.Size = new System.Drawing.Size(310, 24);
            this.cmbNewRole.TabIndex = 5;
            // 
            // txtNewPassword
            // 
            this.txtNewPassword.Location = new System.Drawing.Point(322, 55);
            this.txtNewPassword.Name = "txtNewPassword";
            this.txtNewPassword.Size = new System.Drawing.Size(274, 22);
            this.txtNewPassword.TabIndex = 4;
            this.txtNewPassword.UseSystemPasswordChar = true;
            // 
            // txtNewLogin
            // 
            this.txtNewLogin.Location = new System.Drawing.Point(16, 55);
            this.txtNewLogin.Name = "txtNewLogin";
            this.txtNewLogin.Size = new System.Drawing.Size(274, 22);
            this.txtNewLogin.TabIndex = 3;
            // 
            // lblNewRole
            // 
            this.lblNewRole.AutoSize = true;
            this.lblNewRole.Location = new System.Drawing.Point(619, 28);
            this.lblNewRole.Name = "lblNewRole";
            this.lblNewRole.Size = new System.Drawing.Size(39, 16);
            this.lblNewRole.TabIndex = 2;
            this.lblNewRole.Text = "Роль";
            // 
            // lblNewPassword
            // 
            this.lblNewPassword.AutoSize = true;
            this.lblNewPassword.Location = new System.Drawing.Point(318, 28);
            this.lblNewPassword.Name = "lblNewPassword";
            this.lblNewPassword.Size = new System.Drawing.Size(56, 16);
            this.lblNewPassword.TabIndex = 1;
            this.lblNewPassword.Text = "Пароль";
            // 
            // lblNewLogin
            // 
            this.lblNewLogin.AutoSize = true;
            this.lblNewLogin.Location = new System.Drawing.Point(11, 28);
            this.lblNewLogin.Name = "lblNewLogin";
            this.lblNewLogin.Size = new System.Drawing.Size(46, 16);
            this.lblNewLogin.TabIndex = 0;
            this.lblNewLogin.Text = "Логин";
            // 
            // AdminForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1257, 747);
            this.Controls.Add(this.tabAdminInner);
            this.Controls.Add(this.panelTop);
            this.Controls.Add(this.panelBrand);
            this.Name = "AdminForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Администратор";
            this.panelBrand.ResumeLayout(false);
            this.tableBrand.ResumeLayout(false);
            this.tableBrand.PerformLayout();
            this.panelTop.ResumeLayout(false);
            this.panelTop.PerformLayout();
            this.tabAdminInner.ResumeLayout(false);
            this.tabApplicants.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gridApplicants)).EndInit();
            this.tabStudents.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gridStudents)).EndInit();
            this.panelAddStudent.ResumeLayout(false);
            this.panelAddStudent.PerformLayout();
            this.tabSpecialitiesAdmin.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gridSpecialitiesAdmin)).EndInit();
            this.panelAddSpeciality.ResumeLayout(false);
            this.panelAddSpeciality.PerformLayout();
            this.tabApplications.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gridApplications)).EndInit();
            this.tabAdmitted.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gridAdmitted)).EndInit();
            this.tabUsers.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gridUsers)).EndInit();
            this.panelAddUser.ResumeLayout(false);
            this.panelAddUser.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
    }
}
