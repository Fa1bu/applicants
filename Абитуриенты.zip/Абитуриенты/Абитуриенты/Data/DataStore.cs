using System;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Windows.Forms;
using Абитуриенты;
using Абитуриенты.АбитуриентыDataSetTableAdapters;

namespace Абитуриенты.Data
{
    public sealed class DataStore
    {
        private readonly string _connectionString;

        public DataStore(string connectionString)
        {
            if (string.IsNullOrWhiteSpace(connectionString))
                throw new ArgumentException("connectionString is required", nameof(connectionString));
            _connectionString = ResolveConnectionString(connectionString);
        }

        public static string ResolveConnectionString(string connectionString)
        {
            if (string.IsNullOrEmpty(connectionString))
                return connectionString;

            var dataDir = AppDomain.CurrentDomain.GetData("DataDirectory") as string;
            if (string.IsNullOrEmpty(dataDir))
                dataDir = Application.StartupPath;

            return connectionString
                .Replace("|DataDirectory|", dataDir)
                .Replace("|datadirectory|", dataDir);
        }

        public АбитуриентыDataSet Load()
        {
            var ds = new АбитуриентыDataSet();

            using (var users = new РегистрацияTableAdapter())
            using (var applicants = new АбитуриентыTableAdapter())
            using (var students = new СтудентыTableAdapter())
            using (var specialities = new СпециальностьTableAdapter())
            using (var applications = new Подача_заявленийTableAdapter())
            {
                ConfigureAdapter(users);
                ConfigureAdapter(applicants);
                ConfigureAdapter(students);
                ConfigureAdapter(specialities);
                ConfigureAdapter(applications);

                users.Fill(ds.Регистрация);
                applicants.Fill(ds.Абитуриенты);
                students.Fill(ds.Студенты);
                specialities.Fill(ds.Специальность);
                applications.Fill(ds.Подача_заявлений);
            }

            LoadAdmittedList(ds);

            EnsureSeedData(ds);
            if (ds.HasChanges())
                Save(ds);
            return ds;
        }

        public void Save(АбитуриентыDataSet ds)
        {
            if (ds == null)
                throw new ArgumentNullException(nameof(ds));
            if (!ds.HasChanges())
                return;

            SyncChildForeignKeys(ds);

            var enforceConstraints = ds.EnforceConstraints;
            ds.EnforceConstraints = false;
            try
            {
                using (var manager = new TableAdapterManager())
                using (var users = new РегистрацияTableAdapter())
                using (var applicants = new АбитуриентыTableAdapter())
                using (var students = new СтудентыTableAdapter())
                using (var specialities = new СпециальностьTableAdapter())
                using (var applications = new Подача_заявленийTableAdapter())
                {
                    ConfigureAdapter(users);
                    ConfigureAdapter(applicants);
                    ConfigureAdapter(students);
                    ConfigureAdapter(specialities);
                    ConfigureAdapter(applications);

                    manager.BackupDataSetBeforeUpdate = false;
                    manager.UpdateOrder = TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
                    manager.Connection = users.Connection;

                    manager.РегистрацияTableAdapter = users;
                    manager.АбитуриентыTableAdapter = applicants;
                    manager.СтудентыTableAdapter = students;
                    manager.СпециальностьTableAdapter = specialities;
                    manager.Подача_заявленийTableAdapter = applications;

                    AttachAccessIdentityHandlers(applicants, applications, students, users);
                    try
                    {
                        manager.UpdateAll(ds);
                    }
                    finally
                    {
                        DetachAccessIdentityHandlers(applicants, applications, students, users);
                    }
                }
            }
            finally
            {
                ds.EnforceConstraints = enforceConstraints;
            }
        }

        public void LoadAdmittedList(АбитуриентыDataSet ds)
        {
            if (ds == null)
                throw new ArgumentNullException(nameof(ds));

            using (var admitted = new Список_поступившихTableAdapter())
            {
                ConfigureAdapter(admitted);
                admitted.Fill(ds.Список_поступивших);
            }
        }

        private void ConfigureAdapter(Component adapter)
        {
            if (adapter is РегистрацияTableAdapter u)
                u.Connection.ConnectionString = _connectionString;
            else if (adapter is АбитуриентыTableAdapter a)
                a.Connection.ConnectionString = _connectionString;
            else if (adapter is СтудентыTableAdapter s)
                s.Connection.ConnectionString = _connectionString;
            else if (adapter is СпециальностьTableAdapter sp)
                sp.Connection.ConnectionString = _connectionString;
            else if (adapter is Подача_заявленийTableAdapter p)
                p.Connection.ConnectionString = _connectionString;
            else if (adapter is Список_поступившихTableAdapter admitted)
                admitted.Connection.ConnectionString = _connectionString;
        }

        /// <summary>
        /// Перед записью в БД подставляет реальные ключи родителей в дочерние строки (заявления).
        /// </summary>
        private static void SyncChildForeignKeys(АбитуриентыDataSet ds)
        {
            foreach (АбитуриентыDataSet.Подача_заявленийRow app in ds.Подача_заявлений.Rows)
            {
                if (app.RowState == DataRowState.Deleted || app.RowState == DataRowState.Detached)
                    continue;

                var parent = app.АбитуриентыRow;
                if (parent == null || parent.RowState == DataRowState.Deleted || parent.RowState == DataRowState.Detached)
                    continue;

                if (app.IsКод_абитуриентаNull() || app.Код_абитуриента != parent.Код_абитуриента)
                    app.Код_абитуриента = parent.Код_абитуриента;

                var spec = app.СпециальностьRow;
                if (spec != null && spec.RowState != DataRowState.Deleted && spec.RowState != DataRowState.Detached &&
                    !spec.IsНазвание_специальностиNull() &&
                    (app.IsНазвание_специальностиNull() ||
                     !string.Equals(app.Название_специальности, spec.Название_специальности, StringComparison.Ordinal)))
                {
                    app.Название_специальности = spec.Название_специальности;
                }
            }

            foreach (АбитуриентыDataSet.СтудентыRow stu in ds.Студенты.Rows)
            {
                if (stu.RowState == DataRowState.Deleted || stu.RowState == DataRowState.Detached)
                    continue;

                var spec = stu.СпециальностьRow;
                if (spec == null || spec.RowState == DataRowState.Deleted)
                    continue;

                if (!spec.IsНазвание_специальностиNull() &&
                    (stu.IsНазвание_специальностиNull() || !string.Equals(stu.Название_специальности, spec.Название_специальности, StringComparison.Ordinal)))
                {
                    stu.Название_специальности = spec.Название_специальности;
                }
            }
        }

        private static void AttachAccessIdentityHandlers(
            АбитуриентыTableAdapter applicants,
            Подача_заявленийTableAdapter applications,
            СтудентыTableAdapter students,
            РегистрацияTableAdapter users)
        {
            applicants.Adapter.RowUpdated += ApplicantsAdapter_RowUpdated;
            applications.Adapter.RowUpdated += ApplicationsAdapter_RowUpdated;
            students.Adapter.RowUpdated += StudentsAdapter_RowUpdated;
            users.Adapter.RowUpdated += UsersAdapter_RowUpdated;
        }

        private static void DetachAccessIdentityHandlers(
            АбитуриентыTableAdapter applicants,
            Подача_заявленийTableAdapter applications,
            СтудентыTableAdapter students,
            РегистрацияTableAdapter users)
        {
            applicants.Adapter.RowUpdated -= ApplicantsAdapter_RowUpdated;
            applications.Adapter.RowUpdated -= ApplicationsAdapter_RowUpdated;
            students.Adapter.RowUpdated -= StudentsAdapter_RowUpdated;
            users.Adapter.RowUpdated -= UsersAdapter_RowUpdated;
        }

        private static void ApplicantsAdapter_RowUpdated(object sender, OleDbRowUpdatedEventArgs e)
        {
            if (e.StatementType != StatementType.Insert || e.Row == null)
                return;
            var applicantRow = e.Row as АбитуриентыDataSet.АбитуриентыRow;
            if (applicantRow == null)
                return;

            var newId = ReadAccessIdentity(e.Command);
            // Дочерние строки нужно взять до смены ключа родителя — связь по Код_абитуриента.
            var childApplications = applicantRow.GetПодача_заявленийRows();
            applicantRow.Код_абитуриента = newId;
            foreach (АбитуриентыDataSet.Подача_заявленийRow child in childApplications)
            {
                if (child.RowState == DataRowState.Added || child.RowState == DataRowState.Modified)
                    child.Код_абитуриента = newId;
            }
            e.Status = UpdateStatus.SkipCurrentRow;
        }

        private static void ApplicationsAdapter_RowUpdated(object sender, OleDbRowUpdatedEventArgs e)
        {
            if (e.StatementType != StatementType.Insert || e.Row == null)
                return;
            var row = e.Row as АбитуриентыDataSet.Подача_заявленийRow;
            if (row == null)
                return;
            row.Код_подачи_заявления = ReadAccessIdentity(e.Command);
            e.Status = UpdateStatus.SkipCurrentRow;
        }

        private static void StudentsAdapter_RowUpdated(object sender, OleDbRowUpdatedEventArgs e)
        {
            if (e.StatementType != StatementType.Insert || e.Row == null)
                return;
            var row = e.Row as АбитуриентыDataSet.СтудентыRow;
            if (row == null)
                return;
            row.Код_студента = ReadAccessIdentity(e.Command);
            e.Status = UpdateStatus.SkipCurrentRow;
        }

        private static void UsersAdapter_RowUpdated(object sender, OleDbRowUpdatedEventArgs e)
        {
            if (e.StatementType != StatementType.Insert || e.Row == null)
                return;
            var row = e.Row as АбитуриентыDataSet.РегистрацияRow;
            if (row == null)
                return;
            row.Код_регистрации = ReadAccessIdentity(e.Command);
            e.Status = UpdateStatus.SkipCurrentRow;
        }

        private static int ReadAccessIdentity(OleDbCommand insertCommand)
        {
            var conn = insertCommand.Connection;
            if (conn == null)
                throw new InvalidOperationException("Нет подключения для чтения @@IDENTITY.");

            var tran = insertCommand.Transaction as OleDbTransaction;
            using (var idCmd = tran != null
                ? new OleDbCommand("SELECT @@IDENTITY", conn, tran)
                : new OleDbCommand("SELECT @@IDENTITY", conn))
            {
                var v = idCmd.ExecuteScalar();
                if (v == null || v == DBNull.Value)
                    throw new InvalidOperationException("Не удалось получить @@IDENTITY после вставки.");
                return Convert.ToInt32(Convert.ToDecimal(v));
            }
        }

        private static void EnsureSeedData(АбитуриентыDataSet ds)
        {
            if (ds.Регистрация.Rows.Count == 0)
            {
                ds.Регистрация.AddРегистрацияRow("admin", Security.PasswordHasher.Hash("admin"), "Admin");
                ds.Регистрация.AddРегистрацияRow("user", Security.PasswordHasher.Hash("user"), "User");
            }

            if (ds.Специальность.Rows.Count == 0)
            {
                ds.Специальность.AddСпециальностьRow("Информационные системы и программирование", "3 года 10 месяцев", "200");
                ds.Специальность.AddСпециальностьRow("Сетевое и системное администрирование", "3 года 10 месяцев", "190");
                ds.Специальность.AddСпециальностьRow("Экономика и бухгалтерский учет", "2 года 10 месяцев", "175");
            }
        }
    }
}
