namespace Абитуриенты
{
    partial class UserForm
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.Panel panelBrand;
        private System.Windows.Forms.TableLayoutPanel tableBrand;
        private System.Windows.Forms.Label lblInstitution;
        private System.Windows.Forms.Label lblContacts;
        private System.Windows.Forms.Panel panelTop;
        private System.Windows.Forms.Label lblUser;
        private System.Windows.Forms.Button btnExitApp;
        private System.Windows.Forms.TabControl tabUserInner;
        private System.Windows.Forms.TabPage tabSpecialitiesUser;
        private System.Windows.Forms.TabPage tabSubmitApp;
        private System.Windows.Forms.DataGridView gridSpecialitiesUser;
        private System.Windows.Forms.Panel panelSubmit;
        private System.Windows.Forms.ComboBox cmbSpeciality;
        private System.Windows.Forms.Button btnSubmitApplication;
        private System.Windows.Forms.Label lblSpeciality;
        private System.Windows.Forms.TextBox txtFam;
        private System.Windows.Forms.TextBox txtImya;
        private System.Windows.Forms.TextBox txtOtch;
        private System.Windows.Forms.TextBox txtSumBall;
        private System.Windows.Forms.Label lblFam;
        private System.Windows.Forms.Label lblImya;
        private System.Windows.Forms.Label lblOtch;
        private System.Windows.Forms.Label lblSumBall;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        private void InitializeComponent()
        {
            this.panelBrand = new System.Windows.Forms.Panel();
            this.tableBrand = new System.Windows.Forms.TableLayoutPanel();
            this.lblInstitution = new System.Windows.Forms.Label();
            this.lblContacts = new System.Windows.Forms.Label();
            this.panelTop = new System.Windows.Forms.Panel();
            this.btnExitApp = new System.Windows.Forms.Button();
            this.lblUser = new System.Windows.Forms.Label();
            this.tabUserInner = new System.Windows.Forms.TabControl();
            this.tabSpecialitiesUser = new System.Windows.Forms.TabPage();
            this.gridSpecialitiesUser = new System.Windows.Forms.DataGridView();
            this.tabSubmitApp = new System.Windows.Forms.TabPage();
            this.panelSubmit = new System.Windows.Forms.Panel();
            this.btnSubmitApplication = new System.Windows.Forms.Button();
            this.cmbSpeciality = new System.Windows.Forms.ComboBox();
            this.lblSpeciality = new System.Windows.Forms.Label();
            this.txtSumBall = new System.Windows.Forms.TextBox();
            this.txtOtch = new System.Windows.Forms.TextBox();
            this.txtImya = new System.Windows.Forms.TextBox();
            this.txtFam = new System.Windows.Forms.TextBox();
            this.lblSumBall = new System.Windows.Forms.Label();
            this.lblOtch = new System.Windows.Forms.Label();
            this.lblImya = new System.Windows.Forms.Label();
            this.lblFam = new System.Windows.Forms.Label();
            this.panelBrand.SuspendLayout();
            this.tableBrand.SuspendLayout();
            this.panelTop.SuspendLayout();
            this.tabUserInner.SuspendLayout();
            this.tabSpecialitiesUser.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridSpecialitiesUser)).BeginInit();
            this.tabSubmitApp.SuspendLayout();
            this.panelSubmit.SuspendLayout();
            this.SuspendLayout();
            // 
            // panelBrand
            // 
            this.panelBrand.Controls.Add(this.tableBrand);
            this.panelBrand.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelBrand.Location = new System.Drawing.Point(0, 0);
            this.panelBrand.Name = "panelBrand";
            this.panelBrand.Padding = new System.Windows.Forms.Padding(8);
            this.panelBrand.Size = new System.Drawing.Size(1257, 76);
            this.panelBrand.TabIndex = 0;
            // 
            // tableBrand
            // 
            this.tableBrand.ColumnCount = 2;
            this.tableBrand.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 55F));
            this.tableBrand.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 45F));
            this.tableBrand.Controls.Add(this.lblInstitution, 0, 0);
            this.tableBrand.Controls.Add(this.lblContacts, 1, 0);
            this.tableBrand.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableBrand.Location = new System.Drawing.Point(8, 8);
            this.tableBrand.Name = "tableBrand";
            this.tableBrand.RowCount = 1;
            this.tableBrand.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableBrand.Size = new System.Drawing.Size(1241, 60);
            this.tableBrand.TabIndex = 0;
            // 
            // lblInstitution
            // 
            this.lblInstitution.AutoSize = true;
            this.lblInstitution.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblInstitution.Location = new System.Drawing.Point(3, 0);
            this.lblInstitution.Name = "lblInstitution";
            this.lblInstitution.Size = new System.Drawing.Size(676, 60);
            this.lblInstitution.TabIndex = 0;
            this.lblInstitution.Text = "Российский техникум";
            this.lblInstitution.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblContacts
            // 
            this.lblContacts.AutoSize = true;
            this.lblContacts.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblContacts.Location = new System.Drawing.Point(685, 0);
            this.lblContacts.Name = "lblContacts";
            this.lblContacts.Size = new System.Drawing.Size(553, 60);
            this.lblContacts.TabIndex = 1;
            this.lblContacts.Text = "Тел. 89508238522\r\nbelykh_2007@bk.ru";
            this.lblContacts.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panelTop
            // 
            this.panelTop.Controls.Add(this.btnExitApp);
            this.panelTop.Controls.Add(this.lblUser);
            this.panelTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelTop.Location = new System.Drawing.Point(0, 76);
            this.panelTop.Name = "panelTop";
            this.panelTop.Padding = new System.Windows.Forms.Padding(16, 10, 16, 10);
            this.panelTop.Size = new System.Drawing.Size(1257, 88);
            this.panelTop.TabIndex = 1;
            // 
            // btnExitApp
            // 
            this.btnExitApp.Location = new System.Drawing.Point(0, 0);
            this.btnExitApp.Name = "btnExitApp";
            this.btnExitApp.Size = new System.Drawing.Size(183, 32);
            this.btnExitApp.TabIndex = 2;
            this.btnExitApp.Text = "Выход";
            this.btnExitApp.UseVisualStyleBackColor = true;
            this.btnExitApp.Click += new System.EventHandler(this.btnExitApp_Click);
            // 
            // lblUser
            // 
            this.lblUser.AutoSize = true;
            this.lblUser.Location = new System.Drawing.Point(16, 56);
            this.lblUser.Name = "lblUser";
            this.lblUser.Size = new System.Drawing.Size(112, 16);
            this.lblUser.TabIndex = 0;
            this.lblUser.Text = "Пользователь: -";
            // 
            // tabUserInner
            // 
            this.tabUserInner.Controls.Add(this.tabSpecialitiesUser);
            this.tabUserInner.Controls.Add(this.tabSubmitApp);
            this.tabUserInner.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabUserInner.Location = new System.Drawing.Point(0, 128);
            this.tabUserInner.Name = "tabUserInner";
            this.tabUserInner.SelectedIndex = 0;
            this.tabUserInner.Size = new System.Drawing.Size(1257, 619);
            this.tabUserInner.TabIndex = 2;
            // 
            // tabSpecialitiesUser
            // 
            this.tabSpecialitiesUser.Controls.Add(this.gridSpecialitiesUser);
            this.tabSpecialitiesUser.Location = new System.Drawing.Point(4, 25);
            this.tabSpecialitiesUser.Name = "tabSpecialitiesUser";
            this.tabSpecialitiesUser.Padding = new System.Windows.Forms.Padding(11);
            this.tabSpecialitiesUser.Size = new System.Drawing.Size(1249, 590);
            this.tabSpecialitiesUser.TabIndex = 0;
            this.tabSpecialitiesUser.Text = "Специальности";
            this.tabSpecialitiesUser.UseVisualStyleBackColor = true;
            // 
            // gridSpecialitiesUser
            // 
            this.gridSpecialitiesUser.ColumnHeadersHeight = 29;
            this.gridSpecialitiesUser.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gridSpecialitiesUser.Location = new System.Drawing.Point(11, 11);
            this.gridSpecialitiesUser.Name = "gridSpecialitiesUser";
            this.gridSpecialitiesUser.ReadOnly = true;
            this.gridSpecialitiesUser.RowHeadersWidth = 51;
            this.gridSpecialitiesUser.Size = new System.Drawing.Size(1227, 568);
            this.gridSpecialitiesUser.TabIndex = 0;
            // 
            // tabSubmitApp
            // 
            this.tabSubmitApp.Controls.Add(this.panelSubmit);
            this.tabSubmitApp.Location = new System.Drawing.Point(4, 25);
            this.tabSubmitApp.Name = "tabSubmitApp";
            this.tabSubmitApp.Padding = new System.Windows.Forms.Padding(11);
            this.tabSubmitApp.Size = new System.Drawing.Size(1249, 590);
            this.tabSubmitApp.TabIndex = 1;
            this.tabSubmitApp.Text = "Подать заявление";
            this.tabSubmitApp.UseVisualStyleBackColor = true;
            // 
            // panelSubmit
            // 
            this.panelSubmit.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.panelSubmit.Controls.Add(this.btnSubmitApplication);
            this.panelSubmit.Controls.Add(this.cmbSpeciality);
            this.panelSubmit.Controls.Add(this.lblSpeciality);
            this.panelSubmit.Controls.Add(this.txtSumBall);
            this.panelSubmit.Controls.Add(this.txtOtch);
            this.panelSubmit.Controls.Add(this.txtImya);
            this.panelSubmit.Controls.Add(this.txtFam);
            this.panelSubmit.Controls.Add(this.lblSumBall);
            this.panelSubmit.Controls.Add(this.lblOtch);
            this.panelSubmit.Controls.Add(this.lblImya);
            this.panelSubmit.Controls.Add(this.lblFam);
            this.panelSubmit.Location = new System.Drawing.Point(40, 24);
            this.panelSubmit.Name = "panelSubmit";
            this.panelSubmit.Padding = new System.Windows.Forms.Padding(16, 15, 16, 15);
            this.panelSubmit.Size = new System.Drawing.Size(640, 340);
            this.panelSubmit.TabIndex = 0;
            // 
            // btnSubmitApplication
            // 
            this.btnSubmitApplication.Location = new System.Drawing.Point(21, 278);
            this.btnSubmitApplication.Name = "btnSubmitApplication";
            this.btnSubmitApplication.Size = new System.Drawing.Size(599, 38);
            this.btnSubmitApplication.TabIndex = 9;
            this.btnSubmitApplication.Text = "Подать заявление";
            this.btnSubmitApplication.UseVisualStyleBackColor = true;
            this.btnSubmitApplication.Click += new System.EventHandler(this.btnSubmitApplication_Click);
            // 
            // cmbSpeciality
            // 
            this.cmbSpeciality.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbSpeciality.FormattingEnabled = true;
            this.cmbSpeciality.Location = new System.Drawing.Point(21, 233);
            this.cmbSpeciality.Name = "cmbSpeciality";
            this.cmbSpeciality.Size = new System.Drawing.Size(598, 24);
            this.cmbSpeciality.TabIndex = 8;
            // 
            // lblSpeciality
            // 
            this.lblSpeciality.AutoSize = true;
            this.lblSpeciality.Location = new System.Drawing.Point(18, 207);
            this.lblSpeciality.Name = "lblSpeciality";
            this.lblSpeciality.Size = new System.Drawing.Size(108, 16);
            this.lblSpeciality.TabIndex = 7;
            this.lblSpeciality.Text = "Специальность";
            // 
            // txtSumBall
            // 
            this.txtSumBall.Location = new System.Drawing.Point(21, 168);
            this.txtSumBall.Name = "txtSumBall";
            this.txtSumBall.Size = new System.Drawing.Size(200, 22);
            this.txtSumBall.TabIndex = 6;
            // 
            // txtOtch
            // 
            this.txtOtch.Location = new System.Drawing.Point(21, 118);
            this.txtOtch.Name = "txtOtch";
            this.txtOtch.Size = new System.Drawing.Size(598, 22);
            this.txtOtch.TabIndex = 5;
            // 
            // txtImya
            // 
            this.txtImya.Location = new System.Drawing.Point(340, 58);
            this.txtImya.Name = "txtImya";
            this.txtImya.Size = new System.Drawing.Size(279, 22);
            this.txtImya.TabIndex = 4;
            // 
            // txtFam
            // 
            this.txtFam.Location = new System.Drawing.Point(21, 58);
            this.txtFam.Name = "txtFam";
            this.txtFam.Size = new System.Drawing.Size(280, 22);
            this.txtFam.TabIndex = 3;
            // 
            // lblSumBall
            // 
            this.lblSumBall.AutoSize = true;
            this.lblSumBall.Location = new System.Drawing.Point(18, 142);
            this.lblSumBall.Name = "lblSumBall";
            this.lblSumBall.Size = new System.Drawing.Size(118, 16);
            this.lblSumBall.TabIndex = 2;
            this.lblSumBall.Text = "Суммарный балл";
            // 
            // lblOtch
            // 
            this.lblOtch.AutoSize = true;
            this.lblOtch.Location = new System.Drawing.Point(18, 92);
            this.lblOtch.Name = "lblOtch";
            this.lblOtch.Size = new System.Drawing.Size(70, 16);
            this.lblOtch.TabIndex = 1;
            this.lblOtch.Text = "Отчество";
            // 
            // lblImya
            // 
            this.lblImya.AutoSize = true;
            this.lblImya.Location = new System.Drawing.Point(337, 32);
            this.lblImya.Name = "lblImya";
            this.lblImya.Size = new System.Drawing.Size(33, 16);
            this.lblImya.TabIndex = 1;
            this.lblImya.Text = "Имя";
            // 
            // lblFam
            // 
            this.lblFam.AutoSize = true;
            this.lblFam.Location = new System.Drawing.Point(18, 32);
            this.lblFam.Name = "lblFam";
            this.lblFam.Size = new System.Drawing.Size(66, 16);
            this.lblFam.TabIndex = 0;
            this.lblFam.Text = "Фамилия";
            // 
            // UserForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1257, 747);
            this.Controls.Add(this.tabUserInner);
            this.Controls.Add(this.panelTop);
            this.Controls.Add(this.panelBrand);
            this.Name = "UserForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Пользователь";
            this.panelBrand.ResumeLayout(false);
            this.tableBrand.ResumeLayout(false);
            this.tableBrand.PerformLayout();
            this.panelTop.ResumeLayout(false);
            this.panelTop.PerformLayout();
            this.tabUserInner.ResumeLayout(false);
            this.tabSpecialitiesUser.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gridSpecialitiesUser)).EndInit();
            this.tabSubmitApp.ResumeLayout(false);
            this.panelSubmit.ResumeLayout(false);
            this.panelSubmit.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
    }
}
