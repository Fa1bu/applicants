using System;
using System.Drawing;
using System.Windows.Forms;
using Абитуриенты.Auth;
using Абитуриенты.Data;
using Абитуриенты.Infrastructure;

namespace Абитуриенты
{
    public partial class UserForm : Form
    {
        private readonly DataStore _store;
        private readonly АбитуриентыDataSet _ds;
        private readonly UserSession _session;

        public UserForm(DataStore store, АбитуриентыDataSet ds, UserSession session)
        {
            _store = store ?? throw new ArgumentNullException(nameof(store));
            _ds = ds ?? throw new ArgumentNullException(nameof(ds));
            _session = session ?? throw new ArgumentNullException(nameof(session));

            InitializeComponent();
            AppTheme.Apply(this);
            BrandHeader.Apply(lblInstitution, lblContacts);
            HideTabHeaders(tabUserInner);
            BuildTopNavigationButtons();

            lblUser.Text = $"Пользователь: {_session.Login}   ({UserRoleParser.ToDisplayName(_session.RoleKind)})";
            tabUserInner.SelectedTab = tabSpecialitiesUser;
            BindUser();
        }

        private static void HideTabHeaders(TabControl tabControl)
        {
            tabControl.Appearance = TabAppearance.FlatButtons;
            tabControl.ItemSize = new Size(0, 1);
            tabControl.SizeMode = TabSizeMode.Fixed;
        }

        private void BuildTopNavigationButtons()
        {
            var nav = TopBarLayout.Configure(panelTop, lblUser, btnExitApp);

            nav.Controls.Add(CreateNavButton("Специальности", tabSpecialitiesUser));
            nav.Controls.Add(CreateNavButton("Подать заявление", tabSubmitApp));
        }

        private Button CreateNavButton(string text, TabPage target)
        {
            var btn = new Button
            {
                Text = text,
                Width = 200,
                Height = 32,
                Margin = new Padding(4, 0, 4, 0)
            };

            btn.Click += (s, e) => tabUserInner.SelectedTab = target;
            return btn;
        }

        private void BindUser()
        {
            gridSpecialitiesUser.DataSource = _ds.Специальность;
            gridSpecialitiesUser.ReadOnly = true;
            gridSpecialitiesUser.AllowUserToAddRows = false;
            gridSpecialitiesUser.AllowUserToDeleteRows = false;

            cmbSpeciality.DataSource = _ds.Специальность;
            cmbSpeciality.DisplayMember = "Название_специальности";
            cmbSpeciality.ValueMember = "Название_специальности";
        }

        private void btnExitApp_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnSubmitApplication_Click(object sender, EventArgs e)
        {
            var fam = (txtFam.Text ?? "").Trim();
            var im = (txtImya.Text ?? "").Trim();
            var ot = (txtOtch.Text ?? "").Trim();
            var ball = (txtSumBall.Text ?? "").Trim();

            if (fam.Length == 0 || im.Length == 0)
            {
                MessageBox.Show("Укажите фамилию и имя.", "Заявление", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            АбитуриентыDataSet.СпециальностьRow specialityRow = null;
            if (cmbSpeciality.SelectedItem is System.Data.DataRowView specDrv)
                specialityRow = specDrv.Row as АбитуриентыDataSet.СпециальностьRow;

            if (specialityRow == null)
            {
                MessageBox.Show("Выберите специальность.", "Заявление", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                var applicantRow = _ds.Абитуриенты.AddАбитуриентыRow(fam, im, ot, ball);
                _ds.Подача_заявлений.AddПодача_заявленийRow(applicantRow, specialityRow, DateTime.Now);

                _store.Save(_ds);

                txtFam.Text = "";
                txtImya.Text = "";
                txtOtch.Text = "";
                txtSumBall.Text = "";

                MessageBox.Show("Заявление сохранено в базе данных.", "Заявление", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Не удалось сохранить заявление: " + ex.Message, "Заявление", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
